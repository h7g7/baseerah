from fastapi import FastAPI, UploadFile, File
from .services.ingest import read_file_to_df
from .services.context_inference import infer_context
from .services.cleaning import clean_data
from .services.analytics import analyze
from .services.forecasting import forecast
from .services.recommendations import recommend
from .services.visualization import visualize

app = FastAPI(title="Baseerah API")

@app.post('/analyze')
async def analyze_endpoint(file: UploadFile = File(...)):
    df = read_file_to_df(file)
    context = infer_context(df)
    clean_df = clean_data(df)
    stats, insights = analyze(clean_df, context)
    forecast_res = forecast(clean_df, context)
    recommendations = recommend(stats, insights, forecast_res)
    visuals = visualize(clean_df, context, stats, insights, forecast_res)
    return {
        'context': context,
        'stats': stats,
        'insights': insights,
        'forecast': forecast_res,
        'recommendations': recommendations,
        'visuals': visuals
    }